Be sure to attach a target to the target in the inspector

The 4 points empty game objects are path markers, so set them in a path you want the ai to move through in the scene

Also check the script for specifics and commentary if you want to know more about it
